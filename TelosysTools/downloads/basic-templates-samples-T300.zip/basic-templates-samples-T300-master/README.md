Set of basic templates usable with code generator TelosysTools ver 3.0.0

